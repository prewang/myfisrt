#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@File    : winkytest.py
@Date    : 2024/7/15 15:58
@Author  : winky
@Version : 1.0
@Contact : winky@yuntongxun.com
@License : Copyright (c) 2024, yuntongxun.com. All rights reserved.
@Desc    : 
"""

# 此处开始编写你的代码
str1 = "com.bv;com.dbexchange"
str2 = "com.webapp;"
str3 = "com.xxl.job;"
str4 = "io.bhex;com.bot"